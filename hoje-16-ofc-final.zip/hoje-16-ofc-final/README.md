# 💎 Diamond System

Sistema de Gestão Comercial Premium para Joalherias e Lojas de Alto Padrão

![Version](https://img.shields.io/badge/version-1.0-blue.svg)
![PHP](https://img.shields.io/badge/PHP-8.x-purple.svg)
![MySQL](https://img.shields.io/badge/MySQL-5.7+-orange.svg)
![License](https://img.shields.io/badge/license-Proprietary-red.svg)

---

## 🚀 Sobre o Sistema

O **Diamond System** é uma solução completa de gestão comercial desenvolvida especificamente para joalherias, relojoarias e lojas de produtos premium. Com interface moderna, design sofisticado e funcionalidades robustas, o sistema oferece controle total sobre vendas, estoque, clientes e relatórios analíticos.

---

## ✨ Principais Funcionalidades

### 📊 Dashboard Inteligente
- Visão geral de vendas do dia e do mês
- Gráficos interativos dos últimos 7 dias
- Alertas de estoque baixo
- Vendas recentes em tempo real
- Análise por categoria de produtos

### 💎 Gestão de Produtos
- Cadastro ilimitado de produtos
- Organização por categorias
- Upload de fotos dos produtos
- Controle automático de estoque
- Preço de custo e venda
- Alertas de estoque crítico

### 🛒 Sistema de Vendas
- Processo rápido e intuitivo
- Múltiplas formas de pagamento
- Atualização automática de estoque
- Vinculação com clientes
- Histórico completo de transações

### 👥 Gestão de Clientes
- Cadastro completo com validação de CPF
- Proteção contra duplicatas
- Validação de email
- Busca automática de endereço por CEP
- Histórico de compras

### 🔐 Sistema de Permissões
- **Administrador**: Acesso total ao sistema
- **Gerente**: Gerencia produtos, vendas e usuários
- **Vendedor**: Realiza vendas e cadastra clientes

### 📈 Relatórios Avançados
- Vendas por período
- Produtos mais vendidos
- Melhores clientes
- Análise por forma de pagamento
- Ticket médio
- Gráficos interativos

### 💎 Vitrine Digital
- Catálogo visual elegante
- Apresentação premium dos produtos
- Status de estoque em tempo real

---

## 🛠️ Tecnologias Utilizadas

- **Backend**: PHP 8.x
- **Banco de Dados**: MySQL 5.7+
- **Frontend**: Bootstrap 5.3
- **Gráficos**: Chart.js 4.4
- **Ícones**: Font Awesome 6.4
- **Arquitetura**: MVC (Model-View-Controller)
- **Segurança**: PDO Prepared Statements, Password Hashing

---

## 📋 Requisitos do Sistema

### Servidor
- PHP 8.0 ou superior
- MySQL 5.7 ou superior
- Apache 2.4 ou superior
- Extensões PHP: PDO, PDO_MySQL, cURL, GD

### Cliente (Navegador)
- Chrome, Firefox, Safari ou Edge (versões recentes)
- JavaScript habilitado
- Resolução mínima: 1366x768

---

## 🚀 Instalação

### 1. Configurar XAMPP
```bash
# Copie a pasta do sistema para htdocs
C:\xampp\htdocs\diamond_system\
```

### 2. Criar Banco de Dados
1. Acesse `http://localhost/phpmyadmin`
2. Crie um banco de dados chamado `diamond_system`
3. Importe o arquivo `database.sql`

### 3. Configurar Conexão
Edite o arquivo `config/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'diamond_system');
define('BASE_URL', '/diamond_system/');
```

### 4. Acessar o Sistema
```
http://localhost/diamond_system/
```

**Credenciais padrão:**
- Usuário: `admin`
- Senha: `admin123`

⚠️ **IMPORTANTE**: Altere a senha no primeiro login!

---

## 📁 Estrutura do Projeto

```
diamond_system/
├── assets/
│   ├── css/
│   │   └── style.css          # Estilos customizados
│   ├── js/
│   │   └── masks.js           # Máscaras e validações
│   └── uploads/
│       └── products/          # Imagens dos produtos
├── classes/
│   ├── Category.php           # Gestão de categorias
│   ├── Client.php             # Gestão de clientes
│   ├── Product.php            # Gestão de produtos
│   ├── Sale.php               # Gestão de vendas
│   └── User.php               # Gestão de usuários
├── config/
│   └── config.php             # Configurações gerais
├── includes/
│   ├── header.php             # Cabeçalho
│   ├── sidebar.php            # Menu lateral
│   ├── footer.php             # Rodapé
│   └── simple_pdf.php         # Geração de PDFs
├── api_cep.php                # API de busca de CEP
├── api_validate_cpf.php       # API de validação de CPF
├── categories.php             # Gerenciamento de categorias
├── clients.php                # Gerenciamento de clientes
├── dashboard.php              # Dashboard principal
├── database.sql               # Script do banco de dados
├── index.php                  # Redirecionamento
├── login.php                  # Página de login
├── logout.php                 # Logout
├── products.php               # Gerenciamento de produtos
├── reports.php                # Relatórios
├── sales.php                  # Gerenciamento de vendas
├── users.php                  # Gerenciamento de usuários
└── vitrine.php                # Vitrine de produtos
```

---

## 🔒 Segurança

### Medidas Implementadas
✅ Prepared Statements (proteção contra SQL Injection)
✅ Password Hashing (bcrypt)
✅ Validação de dados em múltiplas camadas
✅ Sistema de sessões seguro
✅ Proteção contra CSRF
✅ Validação de CPF e Email
✅ Controle de acesso baseado em perfis
✅ Proteção contra duplicatas

---

## 🎯 Validações Implementadas

### CPF
- ✅ Validação matemática completa
- ✅ Verificação de CPFs sequenciais
- ✅ Feedback visual em tempo real
- ✅ Proteção contra duplicatas

### Email
- ✅ Validação de formato
- ✅ Verificação de domínio
- ✅ Proteção contra duplicatas

### Dados Gerais
- ✅ Sanitização de inputs
- ✅ Validação de tipos
- ✅ Verificação de integridade

---

## 📊 Diferenciais do Sistema

### 1. Interface Premium
- Design dark sofisticado
- Animações suaves e elegantes
- Efeitos glass-morphism
- Totalmente responsivo

### 2. Experiência do Usuário
- Navegação intuitiva
- Feedback visual imediato
- Notificações centralizadas
- Carregamento rápido

### 3. Confiabilidade
- Transações de banco de dados
- Rollback automático em erros
- Logs de auditoria
- Backup recomendado

### 4. Performance
- Queries otimizadas
- Cache de dados
- Carregamento assíncrono
- Código limpo e organizado

---

## 📞 Suporte

Para dúvidas, sugestões ou suporte técnico:

📧 **Email**: contato@diamondsystem.com
📱 **WhatsApp**: (XX) XXXXX-XXXX
🌐 **Site**: www.diamondsystem.com

---

## 📄 Licença

Este sistema é propriedade exclusiva e não pode ser reproduzido, distribuído ou modificado sem autorização expressa.

© 2025 Diamond System - Todos os direitos reservados

---

## 🎓 Documentação Adicional

- [Manual do Usuário](MANUAL_USUARIO.pdf)
- [Guia de Instalação](GUIA_INSTALACAO.pdf)
- [Apresentação Comercial](APRESENTACAO_DIAMOND_SYSTEM.txt)
- [API Documentation](API_DOCS.md)

---

## 🚀 Roadmap Futuro

- [ ] App Mobile (iOS e Android)
- [ ] Integração com e-commerce
- [ ] API REST completa
- [ ] Relatórios em PDF
- [ ] Integração com WhatsApp Business
- [ ] Backup automático em nuvem
- [ ] Multi-loja
- [ ] Módulo de fidelidade

---

**Desenvolvido com 💎 para joalherias de alto padrão**
