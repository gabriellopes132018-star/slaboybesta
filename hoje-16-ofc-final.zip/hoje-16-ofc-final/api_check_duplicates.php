<?php
require_once 'config/config.php';

header('Content-Type: application/json');

$conn = db_connect();

$type = $_GET['type'] ?? '';
$value = $_GET['value'] ?? '';
$id = $_GET['id'] ?? 0;

$response = ['duplicado' => false, 'mensagem' => ''];

if ($type === 'cpf' && !empty($value)) {
    $cpf = preg_replace('/[^0-9]/', '', $value);
    
    if ($id > 0) {
        $stmt = $conn->prepare("SELECT id FROM clients WHERE cpf = ? AND id != ?");
        $stmt->execute([$cpf, $id]);
    } else {
        $stmt = $conn->prepare("SELECT id FROM clients WHERE cpf = ?");
        $stmt->execute([$cpf]);
    }
    
    if ($stmt->fetch()) {
        $response['duplicado'] = true;
        $response['mensagem'] = 'Já existe um cliente cadastrado com este CPF!';
    } else {
        $response['duplicado'] = false;
        $response['mensagem'] = 'CPF disponível';
    }
} elseif ($type === 'email' && !empty($value)) {
    if ($id > 0) {
        $stmt = $conn->prepare("SELECT id FROM clients WHERE email = ? AND id != ?");
        $stmt->execute([$value, $id]);
    } else {
        $stmt = $conn->prepare("SELECT id FROM clients WHERE email = ?");
        $stmt->execute([$value]);
    }
    
    if ($stmt->fetch()) {
        $response['duplicado'] = true;
        $response['mensagem'] = 'Já existe um cliente cadastrado com este email!';
    } else {
        $response['duplicado'] = false;
        $response['mensagem'] = 'Email disponível';
    }
}

db_close($conn);

echo json_encode($response);
