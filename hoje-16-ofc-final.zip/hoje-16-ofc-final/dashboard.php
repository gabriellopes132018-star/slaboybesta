<?php
require_once 'config/config.php';
require_once 'classes/Product.php';
require_once 'classes/Sale.php';
require_once 'classes/Task.php';

require_login();

$conn = db_connect();

$stats = get_dashboard_stats($conn);
$chart_data = get_chart_data($conn);

$product = new Product($conn);
$sale = new Sale($conn);
$task = new Task($conn);

$low_stock_products = $product->getLowStock(10);
$recent_sales = $sale->getRecentSales(10);
$upcoming_tasks = $task->getUpcomingTasks($_SESSION['user_id'], 7);
$task_stats = $task->getTaskStats($_SESSION['user_id'], $_SESSION['user_role']);

$page_title = 'Dashboard';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-chart-line me-2"></i>Dashboard</h1>
    <div class="btn-toolbar mb-2 d-flex align-items-center gap-2">
        <div class="user-badge">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
        </div>
        <div class="role-badge role-<?php echo $_SESSION['user_role']; ?>">
            <i class="fas fa-shield-alt"></i>
            <span><?php echo ucfirst($_SESSION['user_role'] == 'admin' ? 'Administrador' : ($_SESSION['user_role'] == 'manager' ? 'Gerente' : 'Vendedor')); ?></span>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-blue p-3 rounded-3 me-3">
                        <i class="fas fa-dollar-sign fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Vendas Hoje</p>
                        <h4 class="mb-0"><?php echo format_money($stats['sales_today']); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-emerald p-3 rounded-3 me-3">
                        <i class="fas fa-calendar-alt fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Vendas do Mês</p>
                        <h4 class="mb-0"><?php echo format_money($stats['sales_month']); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-cyan p-3 rounded-3 me-3">
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Total de Clientes</p>
                        <h4 class="mb-0"><?php echo $stats['total_clients']; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card card-dashboard">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="stat-icon-yellow p-3 rounded-3 me-3">
                        <i class="fas fa-exclamation-triangle fa-2x"></i>
                    </div>
                    <div>
                        <p class="text-muted mb-1 small">Estoque Baixo</p>
                        <h4 class="mb-0"><?php echo $stats['low_stock']; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-8">
        <div class="card" style="background-color:#0b0f1a;">
            <div class="card-header border-0" style="background-color:#0b0f1a;">
                <h5 class="card-title mb-0 text-light"><i class="fas fa-wave-square me-2 text-primary"></i>Vendas dos Últimos 7 Dias</h5>
            </div>
            <div class="card-body">
                <canvas id="salesChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-xl-4">
        <div class="card" style="background-color:#0b0f1a;">
            <div class="card-header border-0" style="background-color:#0b0f1a;">
                <h5 class="card-title mb-0 text-light"><i class="fas fa-chart-pie me-2 text-info"></i>Vendas por Categoria</h5>
            </div>
            <div class="card-body">
                <canvas id="categoryChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-exclamation-circle me-2"></i>Produtos com Estoque Baixo</h5>
            </div>
            <div class="card-body">
                <?php if (empty($low_stock_products)): ?>
                    <p class="text-muted text-center py-3">Nenhum produto com estoque baixo.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Produto</th>
                                    <th>Categoria</th>
                                    <th>Estoque</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($low_stock_products as $p): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($p['name']); ?></td>
                                    <td><?php echo htmlspecialchars($p['category_name'] ?? 'N/A'); ?></td>
                                    <td><span class="badge bg-warning"><?php echo $p['stock']; ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="fas fa-shopping-cart me-2"></i>Vendas Recentes</h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_sales)): ?>
                    <p class="text-muted text-center py-3">Nenhuma venda registrada.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">#</th>
                                    <th style="width: 30%;">Cliente</th>
                                    <th style="width: 25%;">Vendedor</th>
                                    <th style="width: 20%;">Total</th>
                                    <th style="width: 15%;">Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_sales as $s): ?>
                                <tr>
                                    <td><span class="badge bg-primary">#<?php echo $s['id']; ?></span></td>
                                    <td><?php echo htmlspecialchars($s['client_name'] ?: 'N/A'); ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($s['user_name'] ?: 'N/A'); ?>
                                        </span>
                                    </td>
                                    <td><strong><?php echo format_money($s['total']); ?></strong></td>
                                    <td><?php echo date('d/m H:i', strtotime($s['sale_date'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-12">
        <div class="card" style="background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%); border: 1px solid rgba(139, 92, 246, 0.3);">
            <div class="card-header" style="background: transparent; border-bottom: 1px solid rgba(139, 92, 246, 0.2);">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-calendar-check me-2 text-primary"></i>Minhas Próximas Tarefas
                        <?php if ($task_stats['overdue'] > 0): ?>
                            <span class="badge bg-danger ms-2"><?php echo $task_stats['overdue']; ?> atrasada(s)</span>
                        <?php endif; ?>
                    </h5>
                    <a href="<?php echo BASE_URL; ?>tasks.php" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-list me-1"></i> Ver Todas
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($upcoming_tasks)): ?>
                    <p class="text-muted text-center py-3"><i class="fas fa-check-circle me-2"></i>Nenhuma tarefa próxima. Tudo em dia!</p>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($upcoming_tasks as $ut): ?>
                        <?php
                        $priority_labels = ['low' => 'Baixa', 'medium' => 'Média', 'high' => 'Alta', 'urgent' => 'Urgente'];
                        $priority_colors = ['low' => 'secondary', 'medium' => 'primary', 'high' => 'warning', 'urgent' => 'danger'];
                        $status_labels = ['pending' => 'Pendente', 'in_progress' => 'Em Progresso', 'completed' => 'Concluída'];
                        $status_colors = ['pending' => 'warning', 'in_progress' => 'info', 'completed' => 'success'];
                        $is_overdue = strtotime($ut['due_date']) < time() && $ut['status'] != 'completed';
                        ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card h-100" style="border-left: 4px solid <?php echo $is_overdue ? '#ef4444' : '#' . ($ut['priority'] == 'urgent' ? 'ef4444' : ($ut['priority'] == 'high' ? 'f59e0b' : ($ut['priority'] == 'medium' ? '3b82f6' : '6b7280'))); ?>; background: rgba(13, 19, 32, 0.5);">
                                <div class="card-body p-3">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="mb-1 flex-grow-1">
                                            <a href="<?php echo BASE_URL; ?>tasks.php?action=view&id=<?php echo $ut['id']; ?>" class="text-white text-decoration-none">
                                                <?php echo htmlspecialchars($ut['title']); ?>
                                            </a>
                                        </h6>
                                        <span class="badge bg-<?php echo $priority_colors[$ut['priority']]; ?> ms-2"><?php echo $priority_labels[$ut['priority']]; ?></span>
                                    </div>
                                    <p class="small text-muted mb-2">
                                        <i class="fas fa-clock me-1"></i>
                                        <span class="<?php echo $is_overdue ? 'text-danger fw-bold' : ''; ?>">
                                            <?php echo date('d/m/Y H:i', strtotime($ut['due_date'])); ?>
                                            <?php if ($is_overdue): ?>
                                                <i class="fas fa-exclamation-triangle ms-1"></i>
                                            <?php endif; ?>
                                        </span>
                                    </p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="badge bg-<?php echo $status_colors[$ut['status']]; ?>"><?php echo $status_labels[$ut['status']]; ?></span>
                                        <small class="text-muted">
                                            <i class="fas fa-user-tie me-1"></i><?php echo htmlspecialchars($ut['assigned_by_name']); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const salesData = <?php echo json_encode($chart_data['sales_week']); ?>;
const categoryData = <?php echo json_encode($chart_data['sales_by_category']); ?>;

// === GRÁFICO DE VENDAS - LINHA DE MONTANHA/ONDA ===
const salesCtx = document.getElementById('salesChart').getContext('2d');
const gradient = salesCtx.createLinearGradient(0, 0, 0, 300);
gradient.addColorStop(0, 'rgba(59, 130, 246, 0.6)');
gradient.addColorStop(0.5, 'rgba(59, 130, 246, 0.3)');
gradient.addColorStop(1, 'rgba(59, 130, 246, 0)');

new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: salesData.map(d => {
            const date = new Date(d.date);
            return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
        }),
        datasets: [{
            label: 'Vendas (R$)',
            data: salesData.map(d => parseFloat(d.total)),
            fill: true,
            borderColor: '#3b82f6',
            backgroundColor: gradient,
            borderWidth: 4,
            tension: 0.5,
            pointRadius: 8,
            pointHoverRadius: 10,
            pointBackgroundColor: '#3b82f6',
            pointBorderColor: '#fff',
            pointBorderWidth: 4,
            pointHoverBackgroundColor: '#2563eb',
            pointHoverBorderColor: '#fff',
            pointHoverBorderWidth: 4,
            shadowOffsetX: 0,
            shadowOffsetY: 4,
            shadowBlur: 10,
            shadowColor: 'rgba(59, 130, 246, 0.5)',
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            intersect: false,
            mode: 'index',
        },
        plugins: {
            legend: { 
                display: true,
                labels: { color: '#94a3b8', font: { size: 14, weight: '600' } }
            },
            tooltip: {
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                titleColor: '#f1f5f9',
                bodyColor: '#94a3b8',
                borderColor: '#3b82f6',
                borderWidth: 2,
                padding: 14,
                displayColors: false,
                titleFont: { size: 14, weight: 'bold' },
                bodyFont: { size: 13 },
                callbacks: {
                    label: context => 'R$ ' + parseFloat(context.raw).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2})
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { 
                    color: 'rgba(59,130,246,0.1)',
                    drawBorder: false
                },
                ticks: { 
                    color: '#94a3b8',
                    font: { size: 12, weight: '500' },
                    callback: function(value) {
                        return 'R$ ' + value.toLocaleString('pt-BR');
                    }
                }
            },
            x: {
                grid: { display: false },
                ticks: { color: '#94a3b8', font: { size: 12, weight: '500' } }
            }
        }
    }
});

// === GRÁFICO DE CATEGORIAS (ROSCA) ===
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: categoryData.map(d => d.category),
        datasets: [{
            data: categoryData.map(d => parseFloat(d.total)),
            backgroundColor: ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: '#94a3b8', padding: 15, font: { size: 12 } }
            },
            tooltip: {
                callbacks: {
                    label: context => context.label + ': R$ ' + parseFloat(context.raw).toFixed(2)
                }
            }
        }
    }
});
</script>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
