<?php
require_once 'config/config.php';
require_once 'classes/User.php';

if (is_logged_in()) {
    redirect(BASE_URL . 'dashboard.php');
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Por favor, insira um email válido.';
    } else {
        $conn = db_connect();
        $user = new User($conn);
        
        $user_data = $user->getByEmail($email);
        
        if ($user_data) {
            $token = $user->createPasswordResetToken($user_data['id']);
            
            if ($token) {
                $reset_link = BASE_URL . "reset_password.php?token=" . $token;
                $success = "Um link de recuperação foi gerado. Acesse: <a href='{$reset_link}' class='text-white fw-bold'>{$reset_link}</a>";
            } else {
                $error = 'Erro ao gerar token de recuperação.';
            }
        } else {
            $success = 'Se o email estiver cadastrado, você receberá um link de recuperação.';
        }
        
        db_close($conn);
    }
}

$page_title = 'Recuperar Senha';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Diamond System</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo BASE_URL; ?>assets/css/style.css" rel="stylesheet">
    
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            padding: 20px;
        }
        
        .login-bg-shape {
            position: absolute;
            border-radius: 50%;
            filter: blur(120px);
            opacity: 0.3;
            animation: float 20s ease-in-out infinite;
        }
        
        .shape-1 {
            width: 600px;
            height: 600px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            top: -200px;
            right: -200px;
        }
        
        .shape-2 {
            width: 400px;
            height: 400px;
            background: linear-gradient(135deg, #10b981, #06b6d4);
            bottom: -100px;
            left: -100px;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            25% { transform: translate(50px, -50px) scale(1.1); }
            50% { transform: translate(-30px, 30px) scale(0.9); }
            75% { transform: translate(40px, 40px) scale(1.05); }
        }
        
        .login-card {
            position: relative;
            z-index: 10;
            width: 100%;
            max-width: 450px;
            background: rgba(10, 15, 26, 0.9) !important;
            backdrop-filter: blur(40px) saturate(180%);
            border: 1px solid rgba(59, 130, 246, 0.3) !important;
            border-radius: 24px !important;
            box-shadow: 0 20px 80px rgba(0, 0, 0, 0.5), 0 0 60px rgba(59, 130, 246, 0.2) !important;
            overflow: hidden;
            animation: slideUp 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #3b82f6, #8b5cf6, transparent);
            animation: shimmerTop 3s linear infinite;
        }
        
        @keyframes shimmerTop {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .login-header {
            text-align: center;
            padding: 40px 32px 28px;
            background: linear-gradient(180deg, rgba(59, 130, 246, 0.08), transparent);
            border-bottom: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .login-logo {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            border-radius: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
            margin-bottom: 20px;
            animation: pulse-logo 3s ease-in-out infinite;
        }
        
        @keyframes pulse-logo {
            0%, 100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7); }
            50% { box-shadow: 0 0 0 20px rgba(59, 130, 246, 0); }
        }
        
        .login-title {
            font-size: 26px;
            font-weight: 900;
            background: linear-gradient(135deg, #60a5fa, #a78bfa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 6px;
        }
        
        .login-subtitle {
            color: var(--muted-text);
            font-size: 14px;
        }
        
        .login-body {
            padding: 32px;
        }
        
        .login-input-group {
            position: relative;
            margin-bottom: 20px;
        }
        
        .login-input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #60a5fa;
            font-size: 18px;
            z-index: 2;
        }
        
        .login-input {
            width: 100%;
            padding: 13px 18px 13px 48px !important;
            background: rgba(59, 130, 246, 0.05) !important;
            border: 2px solid rgba(59, 130, 246, 0.2) !important;
            border-radius: 12px !important;
            color: var(--white-text) !important;
            font-size: 15px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .login-input:focus {
            background: rgba(59, 130, 246, 0.08) !important;
            border-color: #3b82f6 !important;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15) !important;
            transform: translateY(-2px);
        }
        
        .login-btn {
            width: 100%;
            padding: 14px !important;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6) !important;
            border: none !important;
            border-radius: 12px !important;
            color: white !important;
            font-size: 15px !important;
            font-weight: 700 !important;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(59, 130, 246, 0.4);
        }
        
        .login-footer {
            text-align: center;
            padding-top: 16px;
            margin-top: 16px;
            border-top: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .login-footer a {
            color: #60a5fa !important;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .login-footer a:hover {
            color: #3b82f6 !important;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-bg-shape shape-1"></div>
        <div class="login-bg-shape shape-2"></div>
        
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    <i class="fas fa-key"></i>
                </div>
                <h1 class="login-title">Recuperar Senha</h1>
                <p class="login-subtitle">Digite seu email para recuperar a senha</p>
            </div>
            
            <div class="login-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger mb-3">
                        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success mb-3">
                        <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!$success): ?>
                <form method="post">
                    <div class="login-input-group">
                        <i class="fas fa-envelope login-input-icon"></i>
                        <input type="email" class="login-input" name="email" placeholder="Digite seu email" required autofocus>
                    </div>
                    
                    <button type="submit" class="login-btn">
                        <span style="position: relative; z-index: 1;">
                            <i class="fas fa-paper-plane me-2"></i>Enviar Link
                        </span>
                    </button>
                    
                    <div class="login-footer">
                        <a href="login.php">
                            <i class="fas fa-arrow-left me-1"></i>Voltar para o Login
                        </a>
                    </div>
                </form>
                <?php else: ?>
                <div class="login-footer">
                    <a href="login.php">
                        <i class="fas fa-arrow-left me-1"></i>Voltar para o Login
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
