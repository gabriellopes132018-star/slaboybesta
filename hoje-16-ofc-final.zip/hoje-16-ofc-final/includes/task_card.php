<?php
$priority_class = 'priority-' . $t['priority'];
$type_labels = ['task' => 'Tarefa', 'meeting' => 'Reunião', 'appointment' => 'Compromisso'];
$priority_labels = ['low' => 'Baixa', 'medium' => 'Média', 'high' => 'Alta', 'urgent' => 'Urgente'];
$status_labels = ['pending' => 'Pendente', 'in_progress' => 'Em Progresso', 'completed' => 'Concluída', 'cancelled' => 'Cancelada'];

$priority_colors = ['low' => 'secondary', 'medium' => 'primary', 'high' => 'warning', 'urgent' => 'danger'];
$status_colors = ['pending' => 'warning', 'in_progress' => 'info', 'completed' => 'success', 'cancelled' => 'secondary'];

$is_overdue = strtotime($t['due_date']) < time() && $t['status'] != 'completed';
?>

<div class="card task-card <?php echo $priority_class; ?>">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-2">
            <h5 class="card-title mb-0">
                <a href="?action=view&id=<?php echo $t['id']; ?>" class="text-white text-decoration-none">
                    <?php echo htmlspecialchars($t['title']); ?>
                </a>
            </h5>
            <div>
                <span class="task-badge bg-<?php echo $priority_colors[$t['priority']]; ?>">
                    <?php echo $priority_labels[$t['priority']]; ?>
                </span>
            </div>
        </div>
        
        <?php if ($t['description']): ?>
        <p class="card-text text-muted small mb-2">
            <?php echo htmlspecialchars(substr($t['description'], 0, 100)); ?><?php echo strlen($t['description']) > 100 ? '...' : ''; ?>
        </p>
        <?php endif; ?>
        
        <div class="d-flex flex-wrap gap-2 mb-3">
            <span class="task-badge bg-<?php echo $status_colors[$t['status']]; ?>">
                <i class="fas fa-circle me-1"></i><?php echo $status_labels[$t['status']]; ?>
            </span>
            <span class="task-badge bg-dark">
                <i class="fas fa-tag me-1"></i><?php echo $type_labels[$t['type']]; ?>
            </span>
        </div>
        
        <div class="row g-2 small">
            <div class="col-6">
                <div class="text-muted">
                    <i class="fas fa-user me-1"></i> Para: 
                    <span class="text-white"><?php echo htmlspecialchars($t['assigned_to_name']); ?></span>
                </div>
            </div>
            <div class="col-6">
                <div class="text-muted">
                    <i class="fas fa-user-tie me-1"></i> De: 
                    <span class="text-white"><?php echo htmlspecialchars($t['assigned_by_name']); ?></span>
                </div>
            </div>
        </div>
        
        <div class="mt-2">
            <div class="text-muted small">
                <i class="fas fa-clock me-1"></i> Vencimento: 
                <span class="<?php echo $is_overdue ? 'text-danger fw-bold' : 'text-white'; ?>">
                    <?php echo date('d/m/Y H:i', strtotime($t['due_date'])); ?>
                    <?php if ($is_overdue): ?>
                        <i class="fas fa-exclamation-triangle ms-1"></i> ATRASADA
                    <?php endif; ?>
                </span>
            </div>
        </div>
        
        <div class="mt-3 d-flex gap-2">
            <a href="?action=view&id=<?php echo $t['id']; ?>" class="btn btn-sm btn-outline-primary flex-fill">
                <i class="fas fa-eye me-1"></i> Ver Detalhes
            </a>
            <?php if ($user_id == $t['assigned_to']): ?>
            <form method="post" action="?action=update_status&id=<?php echo $t['id']; ?>" class="flex-fill">
                <?php if ($t['status'] == 'pending'): ?>
                <input type="hidden" name="status" value="in_progress">
                <button type="submit" class="btn btn-sm btn-outline-info w-100">
                    <i class="fas fa-play me-1"></i> Iniciar
                </button>
                <?php elseif ($t['status'] == 'in_progress'): ?>
                <input type="hidden" name="status" value="completed">
                <button type="submit" class="btn btn-sm btn-outline-success w-100">
                    <i class="fas fa-check me-1"></i> Concluir
                </button>
                <?php endif; ?>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
