<?php
require_once 'config/config.php';
require_once 'classes/Product.php';
require_once 'classes/Client.php';
require_once 'classes/Sale.php';

require_login();

$conn = db_connect();
$product = new Product($conn);
$client_obj = new Client($conn);
$sale = new Sale($conn);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $client_id = $_POST['client_id'] ?? 0;
    $payment_method = $_POST['payment_method'] ?? '';
    $notes = $_POST['notes'] ?? '';
    $items = json_decode($_POST['items'] ?? '[]', true);
    
    if (empty($items)) {
        display_error('Adicione pelo menos um item à venda.');
    } else {
        $sale_id = $sale->create($client_id, $_SESSION['user_id'], $payment_method, $notes, $items);
        
        if ($sale_id) {
            display_success('Venda realizada com sucesso!');
            redirect(BASE_URL . 'sale_detail.php?id=' . $sale_id);
        } else {
            display_error('Erro ao realizar venda.');
        }
    }
}

$products = $product->getVitrineProducts();
$clients = $client_obj->getAll();

$page_title = 'Nova Venda';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-cash-register me-2"></i>Nova Venda</h1>
    <div class="btn-toolbar mb-2">
        <a href="sales.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post" id="saleForm">
    <input type="hidden" name="items" id="items">
    
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">Produtos</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="product_select" class="form-label">Selecionar Produto</label>
                        <select class="form-select" id="product_select">
                            <option value="">Escolha um produto...</option>
                            <?php foreach ($products as $p): ?>
                            <option value="<?php echo $p['id']; ?>" 
                                data-name="<?php echo htmlspecialchars($p['name']); ?>" 
                                data-price="<?php echo $p['price']; ?>" 
                                data-stock="<?php echo $p['stock']; ?>">
                                <?php echo htmlspecialchars($p['name']); ?> - <?php echo format_money($p['price']); ?> (Est: <?php echo $p['stock']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table" id="itemsTable">
                            <thead>
                                <tr>
                                    <th>Produto</th>
                                    <th>Preço Unit.</th>
                                    <th>Qtd.</th>
                                    <th>Subtotal</th>
                                    <th>Ação</th>
                                </tr>
                            </thead>
                            <tbody id="itemsBody">
                                <tr class="empty-row">
                                    <td colspan="5" class="text-center text-muted">Nenhum item adicionado</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                    <td colspan="2"><strong id="totalDisplay">R$ 0,00</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">Informações da Venda</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="client_id" class="form-label">Cliente (Opcional)</label>
                        <select class="form-select" id="client_id" name="client_id">
                            <option value="">Cliente não registrado</option>
                            <?php foreach ($clients as $c): ?>
                            <option value="<?php echo $c['id']; ?>">
                                <?php echo htmlspecialchars($c['name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="payment_method" class="form-label">Forma de Pagamento</label>
                        <select class="form-select" id="payment_method" name="payment_method" required>
                            <option value="">Selecione...</option>
                            <option value="Dinheiro">Dinheiro</option>
                            <option value="Cartão de Crédito">Cartão de Crédito</option>
                            <option value="Cartão de Débito">Cartão de Débito</option>
                            <option value="PIX">PIX</option>
                            <option value="Transferência">Transferência</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="notes" class="form-label">Observações</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-success btn-lg">
                    <i class="fas fa-check me-2"></i>Finalizar Venda
                </button>
            </div>
        </div>
    </div>
</form>

<script>
let saleItems = [];

document.getElementById('product_select').addEventListener('change', function() {
    const option = this.options[this.selectedIndex];
    if (!option.value) return;
    
    const productId = parseInt(option.value);
    const productName = option.dataset.name;
    const productPrice = parseFloat(option.dataset.price);
    const productStock = parseInt(option.dataset.stock);
    
    const existingItem = saleItems.find(item => item.product_id === productId);
    
    if (existingItem) {
        if (existingItem.quantity < productStock) {
            existingItem.quantity++;
            existingItem.subtotal = existingItem.quantity * existingItem.price;
        } else {
            alert('Quantidade máxima em estoque atingida!');
        }
    } else {
        saleItems.push({
            product_id: productId,
            name: productName,
            price: productPrice,
            quantity: 1,
            subtotal: productPrice,
            max_stock: productStock
        });
    }
    
    this.value = '';
    updateItemsTable();
});

function updateItemsTable() {
    const tbody = document.getElementById('itemsBody');
    tbody.innerHTML = '';
    
    if (saleItems.length === 0) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="5" class="text-center text-muted">Nenhum item adicionado</td></tr>';
        document.getElementById('totalDisplay').textContent = 'R$ 0,00';
        return;
    }
    
    let total = 0;
    
    saleItems.forEach((item, index) => {
        total += item.subtotal;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>R$ ${item.price.toFixed(2).replace('.', ',')}</td>
            <td>
                <input type="number" class="form-control form-control-sm" style="width: 80px;" 
                    value="${item.quantity}" min="1" max="${item.max_stock}" 
                    onchange="updateQuantity(${index}, this.value)">
            </td>
            <td>R$ ${item.subtotal.toFixed(2).replace('.', ',')}</td>
            <td>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeItem(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    document.getElementById('totalDisplay').textContent = 'R$ ' + total.toFixed(2).replace('.', ',');
}

function updateQuantity(index, newQuantity) {
    newQuantity = parseInt(newQuantity);
    
    if (newQuantity <= 0) {
        removeItem(index);
        return;
    }
    
    if (newQuantity > saleItems[index].max_stock) {
        alert('Quantidade maior que o estoque disponível!');
        updateItemsTable();
        return;
    }
    
    saleItems[index].quantity = newQuantity;
    saleItems[index].subtotal = saleItems[index].quantity * saleItems[index].price;
    updateItemsTable();
}

function removeItem(index) {
    saleItems.splice(index, 1);
    updateItemsTable();
}

document.getElementById('saleForm').addEventListener('submit', function(e) {
    if (saleItems.length === 0) {
        e.preventDefault();
        alert('Adicione pelo menos um item à venda!');
        return false;
    }
    
    document.getElementById('items').value = JSON.stringify(saleItems);
});
</script>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
