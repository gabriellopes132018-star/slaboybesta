# Diamond System - Sistema de Gestão Comercial para Joalherias

## Overview

Diamond System é um sistema completo de gestão comercial desenvolvido especificamente para joalherias e lojas de produtos premium. O sistema oferece controle de vendas, estoque, clientes, relatórios analíticos e gestão de usuários com níveis de permissão hierárquicos.

**Core Features:**
- Multi-level authentication system (Admin, Manager, Salesperson)
- Product management with categorization and inventory control
- Complete customer registration with CPF validation
- Sales system with multiple payment methods
- Advanced reporting with interactive charts
- Digital product showcase
- Password recovery via token
- Product image uploads
- Automatic postal code lookup (ViaCEP integration)

**Technology Stack:**
- Backend: PHP 8.x
- Database: MySQL 5.7+
- Frontend: Bootstrap 5.3
- Charts: Chart.js 4.4
- Server Environment: XAMPP (Apache + MySQL + PHP)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### 1. Application Structure (MVC Pattern)

The system follows a Model-View-Controller architecture with clear separation of concerns:

**Models (`classes/` directory):**
- `Category.php` - Category management
- `Client.php` - Customer data handling
- `Product.php` - Product inventory management
- Additional models for Sales, Users, and Reports (referenced in structure)

**Rationale:** MVC pattern chosen for maintainability and separation of business logic from presentation. PHP classes handle database operations and business rules independently of the UI layer.

### 2. Frontend Architecture

**Design System:**
- Custom dark theme with glass-morphism effects
- CSS custom properties for consistent theming (`:root` variables)
- Color palette optimized for premium product displays:
  - Primary: Dark blues (#070b14, #0d1320)
  - Accents: Blue (#3b82f6), Purple (#8b5cf6), Emerald (#10b981)
  - Typography: Inter font family

**UI Components:**
- Bootstrap 5.3 for responsive grid and components
- Custom animations (fadeInUp, slideInRight) for enhanced UX
- Chart.js 4.4 for data visualization

**Rationale:** Dark theme chosen to create premium feel suitable for jewelry retail. Glass-morphism effects provide modern aesthetic while maintaining readability.

### 3. Authentication & Authorization

**Access Control Hierarchy:**
1. Admin - Full system access
2. Manager (Gerente) - Sales and inventory management
3. Salesperson (Vendedor) - Limited to sales operations

**Security Features:**
- Session-based authentication
- Token-based password recovery
- Role-based access control (RBAC)

**Rationale:** Three-tier permission system mirrors typical jewelry store hierarchy, allowing appropriate delegation of responsibilities while maintaining security.

### 4. Data Validation & Input Handling

**Client-Side Validation:**
- Real-time CPF validation with formatting masks (`masks.js`)
- Input sanitization and field constraints
- Visual feedback (invalid/valid states with Bootstrap classes)

**Server-Side Validation:**
- API endpoint for CPF validation (`api_validate_cpf.php`)
- Double validation ensures data integrity

**Rationale:** Client-side validation provides immediate feedback, while server-side validation ensures security even if JavaScript is bypassed.

### 5. File Management

**Upload System:**
- Organized uploads directory (`assets/uploads/products/`)
- Product images stored with hashed filenames for security
- Naming pattern: `{hash}.{extension}` (e.g., `68e5a51cdbf38.png`)

**Rationale:** Hashed filenames prevent directory traversal attacks and filename conflicts while maintaining file type integrity.

### 6. Database Design

**Schema Organization:**
- Products table with category relationships
- Clients table with validated CPF storage
- Sales transactions with payment method tracking
- User management with role-based permissions

**Rationale:** Relational structure chosen for data integrity and complex query support (reports, analytics). MySQL selected for stability and broad hosting support.

## External Dependencies

### Third-Party Services

1. **ViaCEP API**
   - Purpose: Automatic Brazilian postal code lookup
   - Integration: Client-side JavaScript fetch calls
   - Use case: Auto-populate address fields during customer registration

2. **Google Fonts**
   - Font Family: Inter (weights 300-900)
   - Delivery: CDN import in CSS
   - Rationale: Professional typography without self-hosting overhead

### Frontend Libraries

1. **Bootstrap 5.3**
   - Purpose: Responsive framework and UI components
   - Components used: Grid system, forms, cards, modals, alerts

2. **Chart.js 4.4**
   - Purpose: Interactive data visualization
   - Use case: Sales reports, inventory analytics, performance dashboards

3. **Font Awesome** (implied by icon usage)
   - Purpose: Icon library
   - Usage: UI indicators (`fa-times-circle` in validation feedback)

### Development Environment

**XAMPP Stack:**
- Apache HTTP Server
- MySQL Database Server
- PHP 8.x Runtime

**Rationale:** XAMPP provides complete development environment with single installation, ideal for rapid development and easy deployment to similar production environments.

### Browser APIs

1. **Fetch API**
   - Purpose: AJAX requests for CPF validation
   - Fallback: None specified (assumes modern browser)

2. **DOM APIs**
   - Event handling via `addEventListener`
   - Dynamic element creation and manipulation

### Database Connectivity

- **Driver:** PHP MySQLi or PDO (implementation in class files)
- **Connection Pattern:** Centralized database class (standard PHP practice)